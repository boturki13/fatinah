شعار "فطنة" — ملفات جاهزة للرفع إلى Replit
------------------------------------------
logo/fatina-logo.svg           المتجه (يفضّل استخدامه دائماً)
logo/fatina-logo-256/512/1024/2000/3000.png   PNG شفاف بمقاسات مختلفة
logo/fatina-og-1200x630.png    صورة المشاركة الاجتماعية (خلفية بنفسجية)
logo/fatina-icon-1024.png      أيقونة التطبيق
logo/apple-touch-icon-180.png  أيقونة iOS
logo/favicon.ico               أيقونة المتصفح

طريقة الاستخدام في Replit:
1) ارفع مجلد logo داخل public/
2) في الصفحة:  <img src="/logo/fatina-logo.svg" alt="فطنة" />
3) في <head>:
   <link rel="icon" href="/logo/favicon.ico" />
   <link rel="apple-touch-icon" href="/logo/apple-touch-icon-180.png" />
   <meta property="og:image" content="/logo/fatina-og-1200x630.png" />
